import UIKit

public struct Chip {
    public enum ChipType: UInt32 {
        case small = 1
        case medium = 2
        case big = 3
    }
    
    public let chipType: ChipType
    
    public static func make() -> Chip {
        guard let chipType = Chip.ChipType(rawValue: UInt32(arc4random_uniform(3) + 1)) else {
            fatalError("Incorrect random value")
        }
        
        return Chip(chipType: chipType)
    }
    
    public func sodering() {
        let soderingTime = chipType.rawValue
        sleep(UInt32(soderingTime))
    }
}

// MARK: Properties


var nsCondition = NSCondition()
var nsAvailable: Bool = false
var chipStore = [Chip]()

// MARK: Threads

class ChipGeneratingThread: Thread {
    
    override func main() {
        createChip()
    }
    
    func createChip() {
        let timer = Timer.scheduledTimer(
            withTimeInterval: 2,
            repeats: true) { timer in
                nsCondition.lock()
                print("Condition was locked by Thread 1")
                let newChip = Chip.make()
                chipStore.append(newChip)
                print("Chip \(newChip) was created and added to store")
                nsAvailable = true
                nsCondition.signal()
                nsCondition.unlock()
                print("Condition was unlocked by Thread 1")
            }
        RunLoop.current.add(timer, forMode: .common)
        RunLoop.current.run(until: Date(timeInterval: 20, since: .now))
    }
}

class ChipSoderingThread: Thread {
    override func main() {
        soderChip()
    }
    
    func soderChip(){
        while chipStore.isEmpty {
            nsCondition.lock()
            
            while (!nsAvailable) {
                nsCondition.wait()
                print("Thread 2 Waiting for Chip")
            }
            print("Condition was locked by Thread 2")
            let newChip = chipStore.last ?? Chip(chipType: .medium)
            print("Received chip \(newChip) for sodering")
            nsCondition.unlock()
            nsAvailable = false
            Chip.sodering(newChip)
            print("Chip \(newChip) was sodered")
            chipStore.removeLast()
            print("Condition was unlocked by Thread 2")
        }
    }
}

// MARK: Thread instances

var solderChip = ChipSoderingThread()
var createChip = ChipGeneratingThread()

createChip.start()
solderChip.start()
