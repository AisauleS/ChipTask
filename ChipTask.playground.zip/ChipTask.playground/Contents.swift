import UIKit

public struct Chip {
    public enum ChipType: UInt32 {
        case small = 1
        case medium = 2
        case big = 3
    }
    
    public let chipType: ChipType
    
    public static func make() -> Chip {
        guard let chipType = Chip.ChipType(rawValue: UInt32(arc4random_uniform(3) + 1)) else {
            fatalError("Incorrect random value")
        }
        
        return Chip(chipType: chipType)
    }
    
    public func sodering() {
        let soderingTime = chipType.rawValue
        sleep(UInt32(soderingTime))
    }
}

// MARK: Properties

class ChipStorage {
    var nsCondition = NSCondition()
    var nsAvailable: Bool = false
    var chipStore = [Chip]()
    private var runCount = 0
    
    var isEmpty: Bool {
        chipStore.isEmpty
    }
    
    func push(item: Chip) {
        nsCondition.lock()
        nsAvailable = true
        print("Condition was locked by Thread 1")
        chipStore.append(item)
        runCount += 1
        print("Chip \(runCount) created and added to store")
        nsCondition.signal()
        nsCondition.unlock()
        print("Condition was unlocked by Thread 1")
    }
    
    func pop() -> Chip {
        nsCondition.lock()
        while (!nsAvailable) {
            nsCondition.wait()
            print("Thread 2 Waiting for Chip")
        }
        print("Condition was locked by Thread 2")
        print("Received chip  for sodering")
        nsAvailable = false
        nsCondition.unlock()
        print("Condition was unlocked by Thread 2")
        return chipStore.removeLast()
    }
}

// MARK: Threads

class ChipGeneratingThread: Thread {
    private let storage: ChipStorage
    private var timer = Timer()
    
    init(storage: ChipStorage) {
        self.storage = storage
    }
    
    override func main() {
        timer = Timer.scheduledTimer(timeInterval: 2.0, target: self, selector: #selector(createChip), userInfo: nil, repeats: true)
        RunLoop.current.add(timer, forMode: .common)
        RunLoop.current.run(until: Date(timeInterval: 20, since: .now))
    }
    
    @objc func createChip() {
        storage.push(item: Chip.make())
    }
}

class ChipSoderingThread: Thread {
    private var storage: ChipStorage
    
    init(storage: ChipStorage) {
        self.storage = storage
    }
    
    override func main() {
        while storage.isEmpty {
            storage.pop().sodering()
            print("Chip was sodered")
        }
    }
}

// MARK: Thread instances
let storage = ChipStorage()
var soderChip = ChipSoderingThread(storage: storage)
var createChip = ChipGeneratingThread(storage: storage)

createChip.start()
soderChip.start()
